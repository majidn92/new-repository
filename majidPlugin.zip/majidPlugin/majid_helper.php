<?php

function dd($input)
{
    echo "<pre style='color: greenyellow;background-color: black;font-size:16px;'>";
    var_dump($input);
    echo "</pre>";
    die();
}

function miladi_to_jalali($input_date, $show_time = false)
{
    $obj = new jdf;
    $date = substr($input_date, 0, 10);
    $date = explode("-", $date);
    $date = $obj->gregorian_to_jalali($date[0], $date[1], $date[2], '/');
    $date = explode("/", $date);
    $date[0] = convertEnglishToPersian(sprintf("%02d", $date[0]));
    $date[1] = convertEnglishToPersian(sprintf("%02d", $date[1]));
    $date[2] = convertEnglishToPersian(sprintf("%02d", $date[2]));
    $date = implode("/", $date);
    if ($show_time) {
        $time = substr($input_date, 11, 15);
        $time = explode(':', $time);
        $time[0] = convertEnglishToPersian(sprintf("%02d", $time[0]));
        $time[1] = convertEnglishToPersian(sprintf("%02d", $time[1]));
        $time[2] = convertEnglishToPersian(sprintf("%02d", $time[2]));
        $time = implode(":", $time);

        return $date . ' ' . $time;
    }


    return $date;
}

function aparat_url_maker($url)
{
    $clip_url = substr($url, 25);
    if (strpos($clip_url, '?')) {
        $clip_url = trim(explode('?', $clip_url)[0]);
    }
    $final_url = "https://www.aparat.com/video/video/embed/videohash/" . $clip_url . "/vt/frame";
    return $final_url;
}

function convertPersianToEnglish($string)
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    $output = str_replace($persian, $english, $string);
    return $output;
}

function convertEnglishToPersian($string)
{
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

    $output = str_replace($english, $persian, $string);
    return $output;
}

function jalali_to_miladi($input_date)
{
    $time = substr($input_date, 19, 37);
    $time = explode(":", $time);
    $time[0] = sprintf("%02d", convertPersianToEnglish($time[0]));
    $time[1] = sprintf("%02d", convertPersianToEnglish($time[1]));
    $time[2] = sprintf("%02d", convertPersianToEnglish($time[2]));
    $time = implode(":", $time);

    $obj = new jdf;
    $date = substr($input_date, 0, 18);
    $date = explode("/", $date);
    $date = $obj->jalali_to_gregorian($date[0], $date[1], $date[2], '-');
    $date = explode('-', $date);
    $date[0] = sprintf("%02d", $date[0]);
    $date[1] = sprintf("%02d", $date[1]);
    $date[2] = sprintf("%02d", $date[2]);
    $date = implode("-", $date);
    return  $date . ' ' . $time;
}
